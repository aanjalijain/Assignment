CREATE DATABASE assignmentDb;

use assignmentDb;



create table userDetail(
   userId INT NOT NULL ,
   userName VARCHAR(100) ,
   userPassword VARCHAR(40) ,
   userStatus VARCHAR(40) CONSTRAINT userDetail_status 
	CHECK (userStatus IN ('Activated', 'Deactivated')),
   PRIMARY KEY ( userId ),
   CONSTRAINT UN_User UNIQUE (userName)
);
select * from userDetail;

Insert into userDetail values('101','aanjalijain.21@gmail.com','anjali','ACtivated');