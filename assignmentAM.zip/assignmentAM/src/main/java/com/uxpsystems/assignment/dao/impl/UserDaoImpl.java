package com.uxpsystems.assignment.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.uxpsystems.assignment.dao.UserDao;
import com.uxpsystems.assignment.model.UserDetail;


@Repository
public class UserDaoImpl implements UserDao{

	
	private static final Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);
	
	@Autowired
	private SessionFactory sessionFactory; 
	
	
	
	public SessionFactory getSessionFactory(){
		return sessionFactory;
	}
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}

	public void insertUser(UserDetail user) {
		Session session = this.sessionFactory.getCurrentSession();
		session.save(user);
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<UserDetail> getAllUsers() {
		
		Session session =this.sessionFactory.getCurrentSession();
		// TODO Auto-generated method stub
		List<UserDetail> users= session.createQuery("from userDetail").list();
		return users;
	}

	public UserDetail getUserById(long userId) {
		Session session = this.sessionFactory.getCurrentSession();		
		UserDetail user = (UserDetail) session.load(UserDetail.class, new Long(userId));
		return user;
	}
	
	public void updateUserDetails(UserDetail user) {
		
    	  Session session = sessionFactory.getCurrentSession();
    	  session.update(user);
    	  logger.info("User updated successfully");

		
	}
	
	public void deleteUserDetails(long userId) {
		Session session = this.sessionFactory.getCurrentSession();
		UserDetail u = (UserDetail) session.load(UserDetail.class, new Long(userId));
		if(null !=u){
			session.delete(u);
		}
		logger.info("User deleted successfully, User details="+u);
	}
	
	

}
