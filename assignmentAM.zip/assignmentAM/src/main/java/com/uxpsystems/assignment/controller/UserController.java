package com.uxpsystems.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import com.uxpsystems.assignment.model.UserDetail;
import com.uxpsystems.assignment.service.UserService;
import com.uxpsystems.assignment.service.impl.UserServiceImpl;

@RestController
public class UserController {

	@Autowired
	public transient UserService userService;

	
	   @RequestMapping("/")
	   public ModelAndView firstPage() {
		return new ModelAndView("index");
	    }
	 /*---Add new User---*/
	   @PostMapping("/user/addNewUser")
	   public ResponseEntity<?> addNewUser(@RequestBody UserDetail user) {
	      userService.insertUser(user);
	      return ResponseEntity.ok().body("New User has been added");
	   }

	   /*---Get a user by id---*/
	   @SuppressWarnings("unchecked")
	   @GetMapping("/user/getUsersById/{id}")
	   public ResponseEntity<UserDetail> get(@PathVariable("id") long id) {
		   UserDetail user = userService.getUserById(id);
		   if(user==null){
			   System.out.println("User with id " + id + " not found");
		       return (ResponseEntity<UserDetail>) ResponseEntity.notFound();
		        }
	      return ResponseEntity.ok().body(user);
	   }

	   /*---get all users---*/
	   @SuppressWarnings("unchecked")
	   @GetMapping("/user/getUsers")
	   public ResponseEntity<List<UserDetail>> list() {
	      List<UserDetail> user = userService.getAllUsers();
	      
	      if(user.isEmpty()){
	    	  
	    	  return (ResponseEntity<List<UserDetail>>) ResponseEntity.notFound();
	        }
	      return ResponseEntity.ok().body(user);
	   }

	   /*---Update a user by userid---*/
	   @PutMapping("/user/updateUsersbyId/{id}")
	   public ResponseEntity<?> update(@PathVariable("id") long id, @RequestBody UserDetail user) {
		  
		  userService.updateUserDetails(id,user);
	      return ResponseEntity.ok().body("User has been updated successfully.");
	   }

	   /*---Delete a user by userid---*/
	   @DeleteMapping("/user/deleteUsersbyId/{id}")
	   public ResponseEntity<?> delete(@PathVariable("id") long id) {
		   userService.deleteUserDetails(id);
	      return ResponseEntity.ok().body("User has been deleted successfully.");
	   }
	
	
	

	
	
}
