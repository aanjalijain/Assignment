package com.uxpsystems.assignment.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import com.uxpsystems.assignment.dao.UserDao;
import com.uxpsystems.assignment.model.UserDetail;
import com.uxpsystems.assignment.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	
	@Autowired
	private transient UserDao userDao;
	
	 @Autowired
	 private PasswordEncoder passwordEncoder;
	
	public void insertUser(UserDetail user) {
		// TODO Auto-generated method stub
		user.setUserPassword(passwordEncoder.encode(user.getUserPassword()));
		userDao.insertUser(user);
		
	}

	public List<UserDetail> getAllUsers() {
		// TODO Auto-generated method stub
		return userDao.getAllUsers();
	}


	public UserDetail getUserById(long userId) {
		// TODO Auto-generated method stub
		UserDetail user=userDao.getUserById(userId);
		return user;
		
	}

	public void updateUserDetails(long userId,UserDetail user) {
		 UserDetail currentUser = userDao.getUserById(userId);
         currentUser.setUserName(user.getUserName());
	     currentUser.setUserPassword(passwordEncoder.encode(user.getUserPassword()));
	     currentUser.setUserStatus(user.getUserStatus());
		
		
		 userDao.updateUserDetails(currentUser);
		
		// TODO Auto-generated method stub
		
	}

	public void deleteUserDetails(long userId) {
		userDao.deleteUserDetails(userId);
		// TODO Auto-generated method stub
		
	}



	

}
