package com.uxpsystems.assignment.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uxpsystems.assignment.model.UserDetail;


public interface UserDao {

	
	void insertUser(UserDetail user);
	
	List<UserDetail> getAllUsers();
	UserDetail getUserById(long userId);
	void updateUserDetails(UserDetail user);
	void deleteUserDetails(long userId);
}
