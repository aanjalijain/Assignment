package com.uxpsystems.assignment.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.uxpsystems.assignment.model.UserDetail;


public interface UserService {

	
	public void insertUser(UserDetail user);
	public List<UserDetail> getAllUsers();
	public UserDetail getUserById(long userId);
	public void updateUserDetails(long userId,UserDetail user);
	public void deleteUserDetails(long userId);
	
}
